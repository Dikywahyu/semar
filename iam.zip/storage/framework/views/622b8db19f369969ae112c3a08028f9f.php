<aside class="left-sidebar with-vertical">
    <div>
        <div class="brand-logo d-flex align-items-center justify-content-between">
            <a href="<?php echo e(url('/dashboard')); ?>" class="text-nowrap logo-img">
                <img src="../../assets/UNITRI.png" class="dark-logo" height="50px" alt="Logo-Dark" />
                <img src="../../assets/UNITRI.png" class="light-logo" height="50px" alt="Logo-light" />
            </a>
            <a href="javascript:void(0)" class="sidebartoggler ms-auto text-decoration-none fs-5 d-block d-xl-none">
                <i class="ti ti-x"></i>
            </a>
        </div>

        
        <?php
        $menuCollection = collect($menus ?? []);
        ?>

        <?php if($menuCollection->isNotEmpty()): ?>
        <nav class="sidebar-nav scroll-sidebar" data-simplebar>
            <ul id="sidebarnav">
                <?php $__currentLoopData = $menuCollection->groupBy('category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-small-cap">
                    <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                    <span class="hide-menu text-uppercase fw-bold fs-2"><?php echo e($category ?: 'General'); ?></span>
                </li>

                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                // Memastikan akses attribute aman baik format Array ['key'] atau Object ->key
                $menu = (array) $menu;
                ?>
                <li class="sidebar-item <?php echo e(($menu['active'] ?? false) ? 'selected' : ''); ?>">
                    <a class="sidebar-link <?php echo e($menu['class'] ?? ''); ?> <?php echo e(($menu['active'] ?? false) ? 'active' : ''); ?>"
                        href="<?php echo e($menu['url'] ?? '#'); ?>"
                        aria-expanded="false">
                        <span>
                            <?php if(str_contains($menu['icon'] ?? '', ':')): ?>
                            <iconify-icon icon="<?php echo e($menu['icon']); ?>" class="fs-6"></iconify-icon>
                            <?php else: ?>
                            <i class="<?php echo e($menu['icon'] ?? 'ti ti-circle'); ?>"></i>
                            <?php endif; ?>
                        </span>
                        <span class="hide-menu"><?php echo e($menu['title'] ?? 'Untitled'); ?></span>
                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>
        <?php else: ?>
        <div class="p-3 text-center text-muted fs-2">
            Tidak ada menu yang tersedia.
        </div>
        <?php endif; ?>


        <div class="fixed-profile p-3 mx-4 mb-2 bg-secondary-subtle rounded mt-3">
            <div class="hstack gap-3">
                <div class="john-img">
                    <?php if(Auth::user()?->avatar): ?>
                    <img src="<?php echo e(Auth::user()->avatar); ?>" class="rounded-circle" width="40" height="40" alt="user-img" />
                    <?php else: ?>
                    <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(Auth::user()->name ?? 'User')); ?>&background=0085db&color=fff" class="rounded-circle" width="40" height="40" alt="user-img" />
                    <?php endif; ?>
                </div>
                <div class="john-title">
                    <h6 class="mb-0 fs-3 fw-semibold"><?php echo e(Auth::user()->name ?? 'User'); ?></h6>
                    <span class="fs-2 text-muted"><?php echo e(Auth::user()?->getRoleNames()?->first() ?? 'User'); ?></span>
                </div>
                <button class="border-0 bg-transparent text-primary ms-auto"
                    type="button"
                    aria-label="logout"
                    data-bs-toggle="tooltip"
                    data-bs-placement="top"
                    data-bs-title="Logout"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="ti ti-power fs-6"></i>
                </button>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </div>
</aside><?php /**PATH C:\xampp\htdocs\iam\resources\views/layouts/partials/aside.blade.php ENDPATH**/ ?>